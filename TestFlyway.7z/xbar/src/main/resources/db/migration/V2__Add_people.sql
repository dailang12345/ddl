insert into PERSON (ID, NAME) values (1,'Axel;');
insert into PERSON (ID, NAME) values (2, 'Mr. Foo');
insert into PERSON (ID, NAME) values (3, 'HELLO');
insert into PERSON (ID, NAME) values (4, ';')
