package foo;

import org.flywaydb.core.api.configuration.FluentConfiguration;
import org.flywaydb.core.internal.database.DatabaseFactory;
import org.flywaydb.core.internal.database.base.Database;
import org.flywaydb.core.internal.resource.LoadableResource;
import org.flywaydb.core.internal.resource.filesystem.FileSystemResource;
import org.flywaydb.core.internal.sqlscript.SqlScript;

import java.io.File;
import java.nio.charset.StandardCharsets;

public class AppWithFilepath {

    public static void executeSQL(File file){
        FluentConfiguration config = new FluentConfiguration();
        config.dataSource("jdbc:mysql://localhost:3306/public", "root", "123456");
        config.group(true);
        String path = "filesystem:" + file.getAbsolutePath();
        LoadableResource resource = new FileSystemResource(null, file.getAbsolutePath(), StandardCharsets.UTF_8);

        Database db = DatabaseFactory.createDatabase(config, true);
        try {
            SqlScript sqlScript = new SqlScript(db.createSqlStatementBuilderFactory(), resource, config.isMixed());
            db.createSqlScriptExecutor(db.getMainConnection().getJdbcTemplate()).execute(sqlScript);
        } finally {
            db.close();
        }
    }

    public static void main(String[] args) {
            String pathName= "C:\\Users\\A763975\\IdeaProjects\\xbar\\src\\main\\resources\\db\\migration\\V1__Create_person_table.sql";
            File file = new File(pathName);
            executeSQL(file);
    }
}
