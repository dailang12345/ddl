package foo;

import org.flywaydb.core.Flyway;

public class App {

        public static void main(String[] args) {

            Flyway flyway = Flyway.configure().dataSource("jdbc:mysql://localhost:3306/public", "root", "123456").load();
            //flyway.info();
            //flyway.clean();  //清除所有
            //flywau.repair(); //删除 flyway_schema_history 表中失败的记录
            flyway.migrate();

//          flyway.repair();

            // 检查 sql 文件
//          flyway.validate();
     }

}

