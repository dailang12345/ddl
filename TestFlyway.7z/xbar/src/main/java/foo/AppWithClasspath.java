package foo;

import org.flywaydb.core.api.Location;
import org.flywaydb.core.api.configuration.FluentConfiguration;
import org.flywaydb.core.internal.database.DatabaseFactory;
import org.flywaydb.core.internal.database.base.Database;
import org.flywaydb.core.internal.resource.LoadableResource;
import org.flywaydb.core.internal.resource.classpath.ClassPathResource;
import org.flywaydb.core.internal.sqlscript.SqlScript;

public class AppWithClasspath {
    public static void executeSQL(String fileName) {
        FluentConfiguration config = new FluentConfiguration();
        config.dataSource("jdbc:mysql://localhost:3306/public", "root", "123456");
        config.group(true);

        String path = "db/migration/";
        String fileNameWithPath = path + fileName;
        LoadableResource resource = new ClassPathResource(new Location(path), fileNameWithPath, config.getClassLoader(), config.getEncoding());

        Database db = DatabaseFactory.createDatabase(config, true);
        try {
            SqlScript sqlScript = new SqlScript(db.createSqlStatementBuilderFactory(), resource, config.isMixed());
            db.createSqlScriptExecutor(db.getMainConnection().getJdbcTemplate()).execute(sqlScript);
        } finally {
            db.close();
        }
    }

    public static void main(String[] args) {
        String fileName = "V1__Create_person_table.sql";
        executeSQL(fileName);
    }

}
