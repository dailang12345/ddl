package com.example.util;

import com.example.entity.User;

public class Helper {

    public static String buildSqlCondition(){
        System.out.println("===Helper===");
        return "id=#{id}";
    }

    public static String buildSqlCondition(int id){
        System.out.println("===Helper===");
        return "id=#{id}";
    }

    public static String buildSqlCondition(String userName){
        System.out.println("===Helper===");
        return "userName=#{userName}";
    }
}
